"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 04/12/2019
Discreption: Lab 6: 
        The purpse of this program is to build a maze with 150 cells and make them all one complex cell. This will 
        is done by created a disjoint set forest making all of the single cells belong to one tree. Resutls are 
        shown and the preformances are timed. A solution path is also calculated and ploted wihtin the maze 
     
""" 


import matplotlib.pyplot as plt
import numpy as np
import random
import timeit

#the followin functions checks if there is an existing wall between the current cell
#and the next intended cell
def checkWall(walls, x, y):
    for i in range(len(walls)):
        if walls[i][0] == x and walls[i][1] == y or walls[i][1] == x and walls[i][0] == y:
            return False #the jump cannot be made
    return True #returns that it is able to jump to the intended cell

#the following iterative function searches for the path between the start and finish points
def calculatePath(walls, path, rows, colums, cell, finish, history):
    if cell == finish: #path is found and returned
        return True, path
    if (cell + 1) %colums != 0: #jumpts to the right cell
        if checkWall(walls, cell, cell+1) and ((cell+1 in history) == False):
            history.append(cell+1)
            check, path = calculatePath(walls, path, rows, colums, cell+1, finish, history)
            if check:
                path.append([cell, cell+1])
                return True, path
    if cell %colums != 0 and cell: #jumps to the left cell after checking its validity
        if checkWall(walls, cell, cell-1) and ((cell -1 in history) == False):
            history.append(cell-1)
            check, path = calculatePath(walls, path, rows, colums, cell-1, finish, history)
            if check:
                path.append([cell, cell-1])
                return True, path
    if cell - colums >= 0: #jumps to the bottom cell if there is an open path
        if checkWall(walls, cell, cell-colums) and ((cell-colums  in history) == False):
            history.append(cell-colums)
            check, path = calculatePath(walls, path, rows, colums, cell-colums, finish, history)
            if check:
                path.append([cell, cell-colums])
                return True, path
    if cell +colums < rows*colums: #jumps to the top cell if it is vald
        if checkWall(walls, cell, cell+colums) and ((cell +colums in history) == False):
            history.append(cell+colums)
            check , path = calculatePath(walls, path, rows, colums, cell+colums, finish, history)
            if check:
                path.append([cell, cell+colums])
                return True, path
    return False , path

#the following function is the intial call for the iterative function which solves the maze
def solveMaze(walls, rows, columns, start, finish):
    finalPath = []
    history = [start]
    holder, finalPath = calculatePath(walls, finalPath, rows, columns, start, finish, history)
    convertedPath = []
    #the solution path are convereted to x and y coordinates to plot the blue lines for the path
    for i in range(len(finalPath)):
        c1 = finalPath[i][0]%columns
        r1 = (finalPath[i][0]-c1) /columns
        c2 = finalPath[i][1]%columns
        r2 = (finalPath[i][1]-c2) /columns
        convertedPath.append([[c1 +.5, c2+.5], [r1+.5, r2 +.5]])
    return convertedPath

#plots the maze as provided in class
def draw_maze(walls,maze_rows,maze_cols, start=0, finish=0):
    finalPath = solveMaze(walls, maze_rows, maze_cols, start, finish)
    fig, ax = plt.subplots()
    for w in walls:
        if w[1]-w[0] ==1: #vertical wall
            x0 = (w[1]%maze_cols)
            x1 = x0
            y0 = (w[1]//maze_cols)
            y1 = y0+1
        else:#horizontal wall
            x0 = (w[0]%maze_cols)
            x1 = x0+1
            y0 = (w[1]//maze_cols)
            y1 = y0  
        ax.plot([x0,x1],[y0,y1],linewidth=1,color='k')
    sx = maze_cols
    sy = maze_rows
    ax.plot([0,0,sx,sx,0],[0,sy,sy,0,0],linewidth=2,color='k')
    c1 = start%maze_cols
    r1 = (start-c1) /maze_cols
    c2 = finish%maze_cols
    r2 = (finish-c2) /maze_cols
    #fills the start and end cells with green adn red coolors
    ax.fill([c1, c1+1, c1+1, c1, c1], [r1, r1, r1+1, r1+1, r1], color = 'g')
    ax.fill([c2, c2+1, c2+1, c2, c2], [r2, r2, r2+1, r2+1, r2], color = 'r')
    ax.axis('off') 
    ax.set_aspect(1.0)
    for i in range(len(finalPath)): #plots the solution path
        ax.plot(finalPath[i][0], finalPath[i][1], color = 'b')
    plt.show()

#bulds the wall lists as porvided
def wall_list(maze_rows, maze_cols):
    # Creates a list with all the walls in the maze
    w =[]
    for r in range(maze_rows):
        for c in range(maze_cols):
            cell = c + r*maze_cols
            if c!=maze_cols-1:
                w.append([cell,cell+1])
            if r!=maze_rows-1:
                w.append([cell,cell+maze_cols])
    return w
 
#initializes the disjoint set forest list
def DisjointSetForest(size):
    return np.zeros(size,dtype=np.int)-1

#standard find function to find the root of the tree
def find(S,i):
    # Returns root of tree that i belongs to
    if S[i]<0:
        return i
    return find(S,S[i])

#joins two cell's if they belong to different trees
def union(S,i,j):
    ri = find(S,i) 
    rj = find(S,j) 
    if ri!=rj: 
        S[rj] = ri  # Make j's root point to i's root

#comppressed find fucntion where all of the cells point
#direclty to its root
def findC(S,i):
    if S[i] < 0:
        return i
    S[i] = findC(S, S[i])
    return S[i] 

#joins trees together depending on thier existing sizes
def unionBySize(S, i, j):
    ri = findC(S, i)
    rj = findC(S, j)
    if ri!= rj:
        if S[ri] < S[rj]:
            S[ri] += S[rj]
            S[rj] = ri
        else:
            S[rj] += S[ri]
            S[ri] = rj

#returns a boolean if two cells belong to the same tree or not
def checkPath(S, walls, d):
    if findC(S, walls[d][0]) == findC(S, walls[d][1]): 
        return False
    return True


#builds a maze based upon the stndard method
def initiateMaze(maze_rows, maze_cols, start=0, end=0, draw=False):
    #initializes the components to build the maze
    walls = wall_list(maze_rows,maze_cols)
    S = DisjointSetForest(maze_rows * maze_cols)
    setCount = len(S)
    #randomly removes a wall until all cells are connected
    while setCount > 1: 
        d = random.randint(0,len(walls)-1)
        if checkPath(S, walls, d): 
            union(S, walls[d][0], walls[d][1])
            walls.pop(d)
            setCount -=1
    if draw:
        draw_maze(walls,maze_rows,maze_cols, start, end) 

#buids a maze based upon the compressed method
def initiateMazeC(maze_rows, maze_cols, start=0, end=0 ,draw=False):
    #initializes the components to build the mazw
    walls2 = wall_list(maze_rows,maze_cols)
    T = DisjointSetForest(maze_rows * maze_cols)
    setCount2 = len(T)
    #randomly removes a wall until all cells are connected
    while setCount2 > 1: 
        d = random.randint(0,len(walls2)-1)
        if checkPath(T, walls2, d): 
            unionBySize(T, walls2[d][0], walls2[d][1])
            walls2.pop(d)
            setCount2 -=1
    if draw:
        draw_maze(walls2,maze_rows,maze_cols, start, end) 

