"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 04/01/2019
Discreption: Lab 5: 
        The purpse of this program is to act as the main file of two other porgrams that build a hash table and 
        a binary tree. Each function is called and excecuted upon prompt request 
     
""" 

from Hashtable import hashTable
from B_Tree import treeBuilder
from Parse import parseText

loop = True

#the following parses the file before hand
arr1, arr2 = parseText() 

#the is the while loop which pompts the user. 
while loop:

	print("Which would rather choose?")
	print("1. Binary Search Tree")
	print("2. Hash Table")
	number = input("3. Exit\n")

	#trys converting the input into an int. if it fails, the pormpt runs again
	try: 
		choice = int(number)
	except: 
		choice = -1

	#has table runs 
	if choice == 1:
		treeBuilder(arr1, arr2)

	#binary tree runs
	elif choice == 2: 
		hashTable(arr1, arr2)

	#program exits
	elif choice == 3: 
		print("Good Bye!")
		loop = False
	else: 
		print("Try Again")
