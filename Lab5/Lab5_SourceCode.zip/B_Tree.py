"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 04/01/2019
Discreption: Lab 5: 
        The purpse of this program is to construct a binary search tree based on the parse file from 
        the text. This binary tree will then search for key words anc compute its similarties. It's 
        preformance will be times and compared to that of the hash table 
     
""" 

from Parse import parseText
import math
import timeit

class BST(object):
    # Constructor
    def __init__(self, item, LIn, left=None, right=None):  
        self.item = item
        self.L = LIn
        self.left = left 
        self.right = right 

#inserss the item into the bst accoriding to alphebetical order
def Insert(T,newItem, listIn):
    if T == None:
        T =  BST(newItem, listIn)
    elif T.item > newItem:
        T.left = Insert(T.left,newItem, listIn)
    else:
        T.right = Insert(T.right,newItem, listIn)
    return T

#returns the number of items in a BST 
def CountItems (T):
    if T is not None:
        count = 1
        count += CountItems(T.right)
        count += CountItems(T.left)
        return count
    return 0

#searches key word within the tree
def Search(T, k):
    while T is not None:
        if T.item == k:
            return T
        if T.item < k: 
            T = T.right
        elif T.item > k :
            T = T.left
    return T

#computes the similarity between two words using its embeddings
def sim(w0, w1):
    dotSum, sumMag0, sumMag1 = 0.0, 0.0, 0.0
    for i in range(50):
        dotSum += w0.L[i] * w1.L[i]
        sumMag0 += w0.L[i] * w0.L[i]
        sumMag1 += w1.L[i] * w1.L[i]
    sumMag0 = math.sqrt(sumMag0)
    sumMag1 = math.sqrt(sumMag1)
    return round(dotSum/(sumMag0*sumMag1), 4)

#computes the height of the tree
def Height(T): 
    if T is None: 
        return 0  
  
    else:  
        leftH = Height(T.left) 
        rightH = Height(T.right) 
        if (leftH > rightH): #retuns only the biggest count form the left and right sub trees
            return leftH+1
        else: 
            return rightH+1

#main function called from the program
def treeBuilder(arr, samples):
    T = None
    embed = []
    simCount = []
    time = []
    nodeCount = 0

    #constructs the tree by inserting nodes
    start = timeit.default_timer()
    for i in range(len(arr[0][0])):
        T = Insert(T, arr[0][0][i], arr[1][0][i])
        nodeCount +=1
    stop = timeit.default_timer()
    constructionT = stop - start

    #retrieves the embeddings of the key words by searching the binary tree
    for i in range(len(samples)):
        embed.append([Search(T, samples[i][0]), Search(T, samples[i][1])])

    #computes the similarity between the words by using its embedding information
    for i in range(len(embed)):
        start = timeit.default_timer()
        simCount.append(sim(embed[i][0], embed[i][1]))
        stop = timeit.default_timer()
        time.append(stop-start)

    #from here one, the results are printed
    print("Binary Search Tree Stats: ") 
    print("Number of Nodes: ", nodeCount)
    print("Height of Tree : ", Height(T))
    print("Running Time For Binary Search Tree Consturctoin : ", constructionT, " Seconds")
    print()
    print("Reading Word Files to Determine Similarities")
    print()

    for i in range(len(simCount)):
        print("Similarity ",samples[i] ," : ", simCount[i])
    print()

    sums = 0
    for i in range(len(time)):
        sums += time[i]
    avg = sums/len(time)

    print("Average Runnig Time For Binary Search Tree Qeury Processing : ", avg, " Seconds")
    print("Total Time : ", sums , " Seconds")
    print()

