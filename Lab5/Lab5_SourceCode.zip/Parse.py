def parseText():
	f = open('glove.6B.50d.txt',encoding='utf-8')  

	lines = f.readlines()
	for line in f:
		lines = f.readlines()

	glue = [[[]] for x in range(2)]

	for i in range(len(lines)):
		test = lines[i].split()
		glue[0][0].append(test[0])
		for j in range(50):
			test[j+1] = float(test[j+1])
		glue[1][0].append(test[1:])



	w = open('words.txt',encoding='utf-8')  

	lines = w.readlines()
	for line in w:
		lines = w.readlines()

	samples = []

	for i in range(len(lines)):
		test = lines[i].split()
		samples.append(test)

	return glue, samples


