"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 04/01/2019
Discreption: Lab 5: 
        The purpse of this program is to construct a hash table which stores the information of the 
        parsed file. The size of the table doubles by size each time the laod factor reaches one. 
        The preformance of this function is kept on record to compare to that of the binary search
        tree implemitation. 
     
""" 
from Parse import parseText
import math
import timeit

class HashTableC(object):
    def __init__(self,slots):  
        self.item = []
        self.num_items = 0
        self.size = slots
        for i in range(slots):
            self.item.append([])

#resizes the hash table by doubling its current size if the load factor reaches 1
def reSize(H):
   if H.num_items == H.size:
        for i in range(H.size):
            H.item.append([])
        H.item.append([])
        H.size *=2

#insersts element onto hash table
def InsertC(H,k,l):
    reSize(H)
    b = h(k,len(H.item))
    H.item[b].append([k,l])
    H.num_items +=1 

#finds element within the hash table and returns its embeddings
def FindC(H,k):
    b = h(k,len(H.item))
    for i in range(len(H.item[b])):
        if H.item[b][i][0] == k:
            return H.item[b][i][:]
    return b, -1, -1

#computes the bucket location in which the item will be stored in
def h(s,n):
    r = 0
    for c in s:
        r = (r*n + ord(c))% n
    return r

#computes the similarity between two words based on their embeddingss
def sim(w0, w1):
    dotSum, sumMag0, sumMag1 = 0.0, 0.0, 0.0
    for i in range(50):
        dotSum += w0[1][i] * w1[1][i]
        sumMag0 += w0[1][i] * w0[1][i]
        sumMag1 += w1[1][i] * w1[1][i]
    sumMag0 = math.sqrt(sumMag0)
    sumMag1 = math.sqrt(sumMag1)
    return round(dotSum/(sumMag0*sumMag1), 4)

#computes the sandard deviation of the buckets of the hash table
def standardDev(H):
    mean = 0
    for i in range(len(H.item)):
        if H.item[i] is not None:
            mean += len(H.item[i])
    mean = mean /len(H.item)
    dist = 0
    for i in range(len(H.item)):
        if H.item[i] is not None:
            dist += abs(len(H.item[i]) - mean) * abs(len(H.item[i]) - mean)
    return dist/len(H.item)

#function that is called from the main program
def hashTable(arr, samples):

    embed = []
    simCount = []
    time = []
    searchTime = []
    H = HashTableC(991)

    #fills the hash table with the parsed items from the text file
    for i in range(len(arr[0][0])):
        InsertC(H, arr[0][0][i], arr[1][0][i])

    #finds the embeddings of the key words that are going to be compared
    for i in range(len(samples)):
        start = timeit.default_timer()
        embed.append([FindC(H, samples[i][0]), FindC(H, samples[i][1])])
        stop = timeit.default_timer()
        searchTime.append(stop-start)

    #calculates the similarity and times the time it takes
    for i in range(len(embed)):
        start = timeit.default_timer()
        simCount.append(sim(embed[i][0], embed[i][1]))
        stop = timeit.default_timer()
        time.append(stop-start)

    #from here on out, the resutls are displayed
    print("Hash Table Stats : ")
    print("Initial Table Size : 991")
    print("Final Table Size : ", H.size)
    print("Load Factor : " , H.num_items/H.size)
    print("Percentage of Empty Lists : ", ((H.size -H.num_items)/H.size)*100)
    print("Standard Deviation of the Lengths of the Lists: ", standardDev(H))
    print()

    print("Reading Word File to Determine Similarities")
    print()

    for i in range(len(simCount)):
        print("Similarity ", samples[i] ," : ", simCount[i])
    print()

    sums1, sums2 = 0, 0
    for i in range(len(time)):
        sums1 += time[i]
    avg = sums1/len(time)

    for i in range(len(searchTime)):
        sums2 += searchTime[i]
    avg2 = sums2/len(searchTime)

    print("Average Runnig Time For Hash Table Qeury Processing : ", avg, " Seconds")
    print("Total Time : ", sums1 , " Seconds")
    print()
    print("Average Search Time : ", avg2, " Seconds")
    print("Total Time : ", sums2 , " Seconds")
    print()

