"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 03/08/2019
Discreption: Lab 3:
		The purpose of this lab is to construct balanced binary search trees and arrays, as well as plotting the trees
		using matplotlib. Build into the program is a timer to evluate the preforamnce of the functions.  
"""

from TreeBuilder import BuildTree
from TreeBuilder import NewObject
from TreeBuilder import Search
from TreeBuilder import PrintAtDepth
from PrintTrees import PrintTree
from Balanced import BalancedArray
from Balanced import BalancedTree
import random

#the function gest the n number of items the user wants to insert
def GetUserLength():
	lengthIn = input("Input Number Of Items That Are Going To Be Inserted\n")
	return int(lengthIn)


#declaures a BST node for scope use
T = NewObject(None)
loop = True

#the following loop executes the commands the sure wishes to follow
while loop:
	#ask user input from options
	print("Hello! Do you want to proceed with?\n1. Construct Origional Tree\n2. Generate Own Tree")
	print("3. Generate Random Tree With N Items\n4. Build Balanced Tree With Sorted Array Numbers\n5. Print Constructed Tree")
	print("6. Search Tree for k\n7. Print According To Depth\n8. Build A Sorted Array From Constructed Tree")
	choice = input("9. Exit\n")
	try: #the try and except functions to convert input into an integer unless the input isnt a number
		choiceNum = int(choice)
	except ValueError:
		choiceNum = -1
	print("---------------------------------------")

	if (choiceNum == 1): #generates the origional BST 
		A = [10, 4, 15, 2, 8, 12, 18, 1, 3, 5, 9, 7]
		T = BuildTree(A)

	elif(choiceNum == 2): #geneates the user's BST
		length =  GetUserLength() 
		print("Keep Entering Desired Item To Be Inserted.")
		i = 1
		A = [-1]* length
		while i <= length:
			print("Item ", i, end = "")
			itemIN = input(": ")
			item = int(itemIN)
			A[i-1] = item
			i+=1
		T = BuildTree(A)

	elif(choiceNum == 3): #Generates a random tree with N items
		length = GetUserLength()
		A = [-1]* length
		for i in range(length):
			A[i] = random.randint(1,101)
		T = BuildTree(A)

	elif(choiceNum == 4): #Builds a balanced tree with a sorted list of N items
		length = GetUserLength()
		A = [-1]* length
		for i in range(length):
			A[i] = i+1
		T = BalancedTree(A)

	elif(choiceNum == 5): #prints constructed tree
		if T.item is not None:
			PrintTree(T)
		else:
			print("Consturct A Tree First")

	elif(choiceNum == 6): #Searches a constructed tree for item K
		if T.item is not None:
			kIn = input("Enter item desired to be search in the BST : \n")
			k = int(kIn)
			G = Search(T, k)
			if G is None:
				print("Item Not Found in BST")
			else:
				print("Item ", G.item, " Found in BST")
		else:
			print("Consturct A Tree First")

	elif(choiceNum == 7): #Prints the items in the tree according to the depth level 
		if T.item is not None:
			PrintAtDepth(T)
		else:
			print("Consturct A Tree First")

	elif(choiceNum == 8): #Builds a sorted array from a constructed tree
		if T.item is not None:
			BalancedArray(T)
		else:
			print("Consturct A Tree First")

	elif(choiceNum == 9): #exits the program
		print("Goodbye!")
		loop = False
	else:				#allows for re-entry incase of missed input
		print("Try Again")
	print("---------------------------------------")

