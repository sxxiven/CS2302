"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 03/08/2019
Discreption: Lab 3: 
        The purpse of this program is to construct the inital binary search tree that is not balanced. This tree is 
        used to fill a sorted array in Balanced.py which satisfies part 4 of the lab. 
     
""" 

class BST(object):
    # Constructor
    def __init__(self, item, left=None, right=None):  
        self.item = item
        self.left = left 
        self.right = right      
        
def Insert(T,newItem):
    if T == None:
        T =  BST(newItem)
    elif T.item > newItem:
        T.left = Insert(T.left,newItem)
    else:
        T.right = Insert(T.right,newItem)
    return T

#retursn an empty BST node
def NewObject(item):
    T = None
    T = BST(item)
    return T

#returns the number of items in a BST 
def CountItems (T):
    if T is not None:
        count = 1
        count += CountItems(T.right)
        count += CountItems(T.left)
        return count
    return 0

def BuildTree(A):
    T = None
    for a in A:
        T = Insert(T,a)
    return T

#part 2 of the lab which searches an item in a BST using an irative approach
def Search(T, k):
    while T is not None:
        if T.item == k:
            return T
        if T.item < k: 
            T = T.right
        elif T.item > k :
            T = T.left
    return T

#helper function for part 5 which prints the item only if the depth level is correct 
def PrintDepthKeys(T, d, i):
    if T is not None:
        if d == i:
            print(T.item, end = ' ')
            if T.left is None and T.right is None: #checks if this is a leaf so it will not loop again 
                return False
            return True
        if d < i:
            check1 = PrintDepthKeys(T.left, d+1, i)
            check2 = PrintDepthKeys(T.right, d+1, i)

            if check1 or check2:
                return True #returns true if the internal node as at least one childe
    return False

#this is part 5 of the lab which prints all elements located at depth 'd'
def PrintAtDepth(T):
    i = 0
    loop = True
    while loop:
        print("Keys at depth ", end = ' ')
        print(i, end = ' ')
        print(" : ", end = ' ')
        loop = PrintDepthKeys(T, 0, i)
        print()
        i+=1
