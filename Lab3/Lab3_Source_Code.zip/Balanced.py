"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 03/08/20199
Discreption: Lab 3: 
		The purpose of this program is to construct a balanced binary search tree and fill a sorted array
		with elements of a binary search tree. Each function is checked by pring its results. 
     
""" 

from TreeBuilder import CountItems
from TreeBuilder import BuildTree
from TreeBuilder import NewObject
from PrintTrees import PrintTree
from TreeBuilder import PrintAtDepth


# **** Part 3 ****
#the followin is the recursive function that consturcts a blanced tree. 
def FillTree( ar):
	if not ar:	#checks if the array is empty ar[]
		return None
	mid =len(ar)//2	#sets the middle node as the furtre parent
	T = NewObject(ar[mid])
	T.left = FillTree(ar[:mid])
	T.right = FillTree(ar[mid+1:])
	return T
   
#the followin function is called from the main profile
def BalancedTree(arr):	
	T = FillTree(arr)
	return T

# **** Part 4 ****
#the following recrusive function is utlized to fill a sorted array from a binary tree
def FillArray(T,ar, i):
	if T is not None:
		i = FillArray(T.left, ar, i)
		ar[i] = T.item
		i = FillArray(T.right,ar, i+1)
		return i
	return i

#the folliwng function is called from the main file
def BalancedArray(T):
	length =  CountItems(T)	#these two line create the array with the right length
	SortFill = [0] * length
	FillArray(T, SortFill, 0) #recrursive inital call
	
	for i in range (length):
		print(SortFill[i], end = ' ')
	print()


