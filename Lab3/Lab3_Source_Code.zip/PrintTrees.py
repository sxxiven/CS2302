"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 03/08/2019
Discreption: Lab 3: 
        The purpose of this program is to draw a given BST using matplot. The porgram graws cirlces and the 
        appropiet branch that connects the tree with the corresponding item within. 
     
""" 
import numpy as np
import matplotlib.pyplot as plt
import math

#plots the cirlce using its radius
def circle(center,rad):
    n = int(10*rad*math.pi)
    t = np.linspace(0,6.3,n)
    x = center[0]+rad*np.sin(t)
    y = center[1]+rad*np.cos(t)
    return x,y

#the following function draws the branch which connects a child to its parent on the tree
def DrawBranch(ax,T, p, center1, center2, angle):
    if T is not None:
        p[0, 0] = center1[0] - 20*np.sin(angle)
        p[0, 1] = center1[1] - 20*np.cos(angle)
        p[1, 0] = center2[0] + 20*np.sin(angle)
        p[1, 1] = center2[1] + 20*np.cos(angle)
        ax.plot(p[:,0],p[:,1],color='k')

#the followin recursive function is the main function in which circles are set and ploted
def DrawTree(ax,T,center1, p , w, h, wd, angle):
    if T is not None:

        #the following setes the position for the left child
        center2 = center1 * 1
        center2[0] -=w * wd
        center2[1] -=h
        x,y = circle(center1, 20)
        ax.plot(x,y,color='k')  #only plots the current node (a.k.a the parent)
        ax.text(center1[0]-10, center1[1]-5, T.item, fontsize=6) #inserts the number into the cirlce
        DrawBranch(ax,T.left,p, center1 ,center2, angle)
        DrawTree(ax,T.left,center2, p, w, h, wd*w, angle*w)
        
        #the folloiwng sets up the location of the right child
        center2 = center1 * 1
        center2[0] +=w * wd
        center2[1] -=h
        DrawBranch(ax,T.right, p ,center1 ,center2, 6-angle)
        DrawTree(ax,T.right,center2, p, w, h, wd*w, angle*w)


#This definition is called from the main program of which initiates the recursive print call. 
def PrintTree(T):        
    fig, ax = plt.subplots()
    ax.axis('on')
    ax.set_aspect(1.0)
    ax.yaxis.set_major_locator(plt.NullLocator())
    ax.xaxis.set_major_locator(plt.NullLocator())
    height = 100
    width = 600
    line = np.array([[0,0],[2000,2000]])

    DrawTree(ax,T,[1000, 1000], line,.50, height, width, 1.5)
    plt.show()
    fig.savefig('Tree.png')

