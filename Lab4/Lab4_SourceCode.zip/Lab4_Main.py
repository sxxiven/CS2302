"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 03/24/2019
Discreption: Lab 3:
        This is the main program of which lab 4 is built. It realies on the attached file to complete the
        given tasks. This prgram mainly focuses on the user interface and timing the task executions.    
"""

from B_Tree import BuildTree
from B_Tree import Height
from B_Tree import SortList
from B_Tree import SmallestAtD
from B_Tree import LargestAtD
from B_Tree import CountAtD
from B_Tree import PrintAtD
from B_Tree import CountFullNodes
from B_Tree import FullLeaves
from B_Tree import DepthAtK

import timeit

#sets loop value and builds the b-tree
T = BuildTree()
loop = True

#the while loops execeutes the user interface a
while loop:
	print("Hello! Do you want to proceed with?\n1.  Find Height Of Tree\n2.  Extract Items Into Sorted List")
	print("3.  Print Smallest At Depth D\n4.  Print Largest At Depth D\n5.  Count Nodes In Tree At Depth D")
	print("6.  Print Items At Depth D\n7.  Return Full Nodes\n8.  Return Full Leaf Nodes\n9.  Find Depth Of Item K\n10.  Time Trials")
	choice = input("11. Exit\n")
	try: #the try and except functions to convert input into an integer unless the input isnt a number
		choiceNum = int(choice)
	except ValueError:
		choiceNum = -1
	print("---------------------------------------")
	if (choiceNum == 1): #outputs the height of the tree
		print("Height Of Tree Is : ",Height(T))

	elif(choiceNum == 2): #extracts items into a sorted list.
		L = []
		SortList(T, L)
		print(L)

	
	elif(choiceNum == 3): #prints smallest at depth d 
		dIn = input("Input Desired Depth : \n")
		d = int(dIn)
		print("Smallest At Depth ", d, "Is : ", SmallestAtD(T, d))

	elif(choiceNum == 4): # Prints Largest at depth d
		dIn = input("Input Desired Depth : \n")
		d = int(dIn)
		print("Largest At Depth ", d, "Is : ", LargestAtD(T, d))

	elif(choiceNum == 5): #count the number of nodes in the tree
		dIn = input("Input Desired Depth: \n")
		d = int(dIn)
		print("Number Of Nodes Within The Tree At Depth ", d," Is : ", CountAtD(T, d))

	elif(choiceNum == 6): #prints items at depth d
		dIn = input("Input Desired Depth: \n")
		d = int(dIn)
		print("The Items At Depth ", d," Are : ")
		PrintAtD(T, d)
		print()

	elif(choiceNum == 7): #returns the number of full nodes within the tree 
		print("The Nuber Of Full Nodes Are: ", CountFullNodes(T))

	elif(choiceNum == 8): #returns the number of full leaf nodes
		print("The Number Of Full Leaf Nodes Are : ", FullLeaves(T))


	elif(choiceNum == 9): #Finds the depth level of node containing the item k
		kIn = input("Input The Desired Item Value To Be Searched: \n")
		k = int(kIn)
		print("The Depth Level Of",k," Is : ", DepthAtK(T, k))
	
	elif(choiceNum == 10): #exits the program
		dIn = input("Input Desired Depth For Test: \n")
		d = int(dIn)
		kIn = input("Input Desired K For Test: \n")
		k = int(dIn)

		times = []

		#part 1
		start = timeit.default_timer() # starts timer
		Height(T)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)

		#part 2
		arr=[]
		start = timeit.default_timer() # starts timer
		SortList(T, arr)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)
		
		#part 3
		start = timeit.default_timer() # starts timer
		SmallestAtD(T,d)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)
		
		#part 4
		start = timeit.default_timer() # starts timer
		LargestAtD(T, d)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)
		
		#part 5
		start = timeit.default_timer() # starts timer
		CountAtD(T,d)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)

		#part 6
		start = timeit.default_timer() # starts timer
		PrintAtD(T,d)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)
		
		#part 7
		start = timeit.default_timer() # starts timer
		CountFullNodes(T)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)
		
		#part 8
		start = timeit.default_timer() # starts timer
		FullLeaves(T)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)
		
		#part 9
		start = timeit.default_timer() # starts timer
		DepthAtK(T,k)
		stop = timeit.default_timer() # ends timer
		times.append(stop - start)

		print()
		print("The Following Time Executions Are In Seconds")
		for i in range(9):
			print("Part ", i+1 , " Time Execution: ", times[i])


	elif(choiceNum == 11): #exits the program
		print("Goodbye!")
		loop = False
	
	else:				#allows for re-entry incase of missed input
		print("Try Again")
	print("---------------------------------------")


