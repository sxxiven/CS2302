"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 03/24/2019
Discreption: Lab 3:
        The following program is desinged to explore methods involving the b-trees. Each part of the lab 
        achieves a specific purpose with results shown.   
"""

import math

class BTree(object):
    # Constructor
    def __init__(self,item=[],child=[],isLeaf=True,max_items=5):  
        self.item = item
        self.child = child 
        self.isLeaf = isLeaf
        if max_items <3: #max_items must be odd and greater or equal to 3
            max_items = 3
        if max_items%2 == 0: #max_items must be odd and greater or equal to 3
            max_items +=1
        self.max_items = max_items

def FindChild(T,k):
    for i in range(len(T.item)):
        if k < T.item[i]:
            return i
    return len(T.item)
             
def InsertInternal(T,i):
    if T.isLeaf:
        InsertLeaf(T,i)
    else:
        k = FindChild(T,i)   
        if IsFull(T.child[k]):
            m, l, r = Split(T.child[k])
            T.item.insert(k,m) 
            T.child[k] = l
            T.child.insert(k+1,r) 
            k = FindChild(T,i)  
        InsertInternal(T.child[k],i)   
            
def Split(T):
    mid = T.max_items//2
    if T.isLeaf:
        leftChild = BTree(T.item[:mid]) 
        rightChild = BTree(T.item[mid+1:]) 
    else:
        leftChild = BTree(T.item[:mid],T.child[:mid+1],T.isLeaf) 
        rightChild = BTree(T.item[mid+1:],T.child[mid+1:],T.isLeaf) 
    return T.item[mid], leftChild,  rightChild   
      
def InsertLeaf(T,i):
    T.item.append(i)  
    T.item.sort()

def IsFull(T):
    return len(T.item) >= T.max_items

def Insert(T,i):
    if not IsFull(T):
        InsertInternal(T,i)
    else:
        m, l, r = Split(T)
        T.item =[m]
        T.child = [l,r]
        T.isLeaf = False
        k = FindChild(T,i)  
        InsertInternal(T.child[k],i)   
        
                
def PrintD(T,space):
    # Prints items and structure of B-tree
    if T.isLeaf:
        for i in range(len(T.item)-1,-1,-1):
            print(space,T.item[i])
    else:
        PrintD(T.child[len(T.item)],space+'   ')  
        for i in range(len(T.item)-1,-1,-1):
            print(space,T.item[i])
            PrintD(T.child[i],space+'   ')
# ************* Below are the lab parts   *************

#Part 1: Printing the height of the tree
def Height(T):
    if T.isLeaf:
        return 0
    return 1+ Height(T.child[-1])

#Part 2: Appending a list through inorder transversal
def SortList(T, arr):
    if not T.isLeaf:
        track = 0
        #this for loop goes through a node's children inorder including themselves
        for i in range(len(T.child)):
            if i == FindChild(T, T.item[track]):
                arr.append(T.item[track])
                track +=1 
            SortList(T.child[i], arr)  
    else:
        #prints the node otherwise
        for i in range(len(T.item)):
            arr.append(T.item[i])   
    return 

#Part 3: Returns the smallest item at depth
def SmallestAtD(T, d):
    if d == 0:
        return T.item[0]
    if T.isLeaf:
        return -math.inf
    return SmallestAtD(T.child[0], d-1)

#Part 4: Returns the largest item at depth 
def LargestAtD(T, d):
    if d == 0:
        return T.item[-1]
    if T.isLeaf:
        return -math.inf
    return LargestAtD(T.child[-1], d-1)

#Part 5: Returns the number of nodes at the given depth
def CountAtD(T, d):
    if d == 0: 
        return 1 #only returns a value of one if the depth value is 0
    if T.isLeaf:
        return -math.inf #returns a negative inf. if depth exceeds height
    count = 0
    for i in range(len(T.child)):
        count+=CountAtD(T.child[i], d-1)
    return count
   
#Part 6: Prints all items at given depth
def PrintAtD(T, d):
    if d == 0:
        for i in range(len(T.item)):
            print(T.item[i], end = ' ')
        return 1 
    if T.isLeaf:
        print("Out Of Range", end = ' ')
        return -1

    else:
        check = 1
        for i in range(len(T.child)):
            if check > 0:
                check = PrintAtD(T.child[i], d-1)
    return 1

#Part 7: Returns the number of nodes that are full
def CountFullNodes(T):
    if len(T.item) == T.max_items:
        return 1
    count = 0
    for i in range(len(T.child)):
        count += CountFullNodes(T.child[i])
    return count

#Part 8: Returns the number of leaf nodes that are full
def FullLeaves(T):
    if len(T.item) == T.max_items and T.isLeaf: #also checks if its a leaf
        return 1
    count = 0
    for i in range(len(T.child)):
        count += CountFullNodes(T.child[i])
    return count

#Part 9: Prtins the level of which item k is found
def DepthAtK(T, k):
    if k in T.item:
        return 0
    if T.isLeaf:
        return -1 #returns a -1 if k is not within the tree. 
    count = DepthAtK(T.child[FindChild(T,k)],k)
    if count >-1:
        return count +1
    return count

#the folloiwng definition is set to create the initial b-tree
def BuildTree():
    L = [30, 50, 10, 20, 60, 70, 100, 40, 90, 80, 110, 120, 1, 11 , 3, 4, 5,105, 115, 200, 2, 45, 6]
    T = BTree()    
    for i in L:
        Insert(T,i) 
    PrintD(T,'')
    return T

