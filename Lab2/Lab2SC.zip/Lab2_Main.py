"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 02/22/2019
Discreption: Lab 2: 
	The purpose of this program is to find the mediam on a random generated list of length n. It retrieves the medium
	by first sorting the list in four different ways; bubble sort, merge sort, quick sort and a modified quick sort. 
	The result, if chosen to display, shows the number of comparisons made and the given time it took for each sorting. 
    
"""
from BuildLists import BuildList1
from BuildLists import Print
from BuildLists import Copy
from BubbleSort import Section1
from MergeSort import Section2
from QuickSort import Section3
from QuickSortMod import Section4
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt2
import timeit
import numpy as np


#asks for suer input 
choice = input("Hello! Do you want to proceed with a time trial?\n1. Yes\n2. No\n")
choiceNum = int(choice)
nInput = input("Input the N'th length desired. \n")
n = int (nInput)

if(choice == "Yes" or choiceNum == 1): #user chose to display results
	print(" * Note : The test will time the sorting algorythms to produce the mediam from lengths of 0 to the inputed length of N")
	
	#sets the size of the array of which the run times are going to be stored
	counts1 = [0] * n 
	counts2 = [0] * n 
	counts3 = [0] * n 
	counts4 = [0] * n 
	times1 = [0] * n 
	times2 = [0] * n 
	times3 = [0] * n 
	times4 = [0] * n 

	fig, ax = plt.subplots()
	fig, ax = plt2.subplots()

	for i in range(0, n, 1): #creates a lists to record results from length 0 to n

		L = BuildList1(i)
		if (L.head == None):
			n = 0
		L1 = Copy(L, 0, i)
		L2 = Copy(L, 0, i)
		L3 = Copy(L, 0, i)
		L4 = Copy(L, 0, i)


		start = timeit.default_timer() # starts timer
		Mid1, count = Section1(L1, i)
		stop = timeit.default_timer() # ends timer
		times1[i] = stop - start #stores the lapsed time 
		counts1[i] = count

		start = timeit.default_timer() 
		Mid2, count = Section2(L2, i)
		stop = timeit.default_timer()
		times2[i] = stop - start 
		counts2[i] = count

		start = timeit.default_timer() 
		Mid3 , count = Section3(L3, i)
		stop = timeit.default_timer()
		times3[i] = stop - start 
		counts3[i] = count 

		start = timeit.default_timer() 
		Mid4 , count = Section4(L4, i)
		stop = timeit.default_timer()
		times4[i] = stop - start 
		counts4[i] = count

    #proceeds to plot the results for the comparison count
	plt.close("all") 
	plt.title('Comparison Count')
	plt.xlabel('Length of List')
	plt.ylabel('Number of Comparisons')
	x = np.arange(0, i+1, 1)
	plt.plot(x, counts1, 'k', label='Bubble Sort')
	plt.plot(x, counts2, 'r', label='Merge Sort')
	plt.plot(x, counts3, 'b', label='Quick Sort')
	plt.plot(x, counts4, 'g', label='Mod Quick Sort')
	plt.legend()
	plt.savefig('ComparisonCounts')
	plt.show()

	#proceeds to plot the results for the time 
	plt2.close("all") 
	plt2.title('Time Excecution')
	plt2.xlabel('Length of List')
	plt2.ylabel('Time (Seconds)')
	plt2.plot(x, times1, 'k', label='Bubble Sort')
	plt2.plot(x, times2, 'r', label='Merge Sort')
	plt2.plot(x, times3, 'b', label='Quick Sort')
	plt2.plot(x, times4, 'g', label='Mod Quick Sort')
	plt2.legend()
	plt2.savefig('Times')
	plt2.show()
	

else: #only the medium is displayed

	L = BuildList1(n)
	if (L.head == None):
		n = 0
	L1 = Copy(L, 0, n)
	L2 = Copy(L, 0, n)
	L3 = Copy(L, 0, n)
	L4 = Copy(L, 0, n)

	print("The Medium are: ")
	
	Mid1, count = Section1(L1, n)
	print(Mid1)
	
	Mid2, count = Section2(L2, n)
	print(Mid2)

	Mid3, count = Section3(L3, n)
	print(Mid3)

	Mid4, count = Section4(L4, n)
	print(Mid4)




