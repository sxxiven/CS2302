"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 02/22/2019
Discreption: Lab 2:
    The purpose of this program is to serve as basic manipulation of a likned list. Wheter it to build it, copy it, or
    find the middle item, it is all done here. Some functions are called from other files.   
"""

import random

class Node(object):
 
    def __init__(self, item, next=None):  
        self.item = item
        self.next = next 

class List(object):   

    def __init__(self): 
        self.head = None
        self.tail = None

def IsEmpty(L):  
    return L.head == None    
        
def Append(L,x): 
    
    if IsEmpty(L):
        L.head = Node(x)
        L.tail = L.head
    else:
        L.tail.next = Node(x)
        L.tail = L.tail.next
        
def Print(L):
    temp = L.head
    while temp is not None:
        print(temp.item, end=' ')
        temp = temp.next
    print()  # New line x
    
def Copy(L, start, end):
    
    L2 = List()
    temp = L.head
    count = 1

    while temp is not None and count <= end:
        
        if (count > start):
            Append(L2, temp.item)

        temp = temp.next
        count += 1
    return L2


def GetMidNode(L, count):
    if IsEmpty(L) or count == 0:
        return None
    else:
        temp = L.head
        i = 1
        while (i != count):
            temp = temp.next
            i+=1
        return temp.item


def BuildList1(n):

    L = List()

    for i in range(n):
        Append(L, random.randint(1,101))
    return L