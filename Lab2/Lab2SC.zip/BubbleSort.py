"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 02/22/2019
Discreption: Lab 2: 
	This pogram is desinged to sort the list using bubble sort in order to retrieve the median
"""

from BuildLists import GetMidNode

def IsEmpty(L): #checks if the the head is empty or not
    return L.head == None  

def Sort(L): #Bubble sort function 
	track = 0
	if IsEmpty(L):
		return True
	else:
		done = False
		while(done == False):
			done = True
			temp = L.head
			while temp.next is not None:
				track += 1	# keep strak of the comparison count
				if (temp.item > temp.next.item):
					tempItem = temp.item
					temp.item = temp.next.item
					temp.next.item = tempItem
					done = False
				temp = temp.next
	return track

#main functino call from the main program 
def Section1(L, n):
	Track = Sort(L)
	return GetMidNode(L, n//2), Track  #returns the medium and the comparison count

