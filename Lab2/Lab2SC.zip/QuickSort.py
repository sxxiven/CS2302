"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 02/22/2019
Discreption: Lab 2:
	The purpose of this program is to sort a given lists with length n using the quick sort method. The list comes as 
	a linked lists and returns the median after is is all sorted 
"""

from BuildLists import GetMidNode

def partion(L, start, end, track): #quick sort partion call
	
	pivotNode = start
	pivotPrev = pivotNode
	transverse = start.next

	while transverse != end.next:	#comparison are made here

		if(start.item >= transverse.item): #switched items occur if with the comparison of vlues
			pivotPrev = pivotNode
			pivotNode = pivotNode.next
			hold = pivotNode.item
			pivotNode.item = transverse.item
			transverse.item = hold

		transverse = transverse.next
		track += 1 #keeps track in the number of comparions

	hold = start.item
	start.item = pivotNode.item
	pivotNode.item = hold

	return pivotPrev, track

def quickSort(L, start, end, track): #quick sort main recursive call function
	if start != end and end.next is not start:
		
		previousNode , track = partion(L, start, end, track) #partions the lists
		track = quickSort(L, start, previousNode, track)	#the follwing are recursive calles for either side of the pivot
		track = quickSort(L, previousNode.next.next, end, track)
	return track


def Section3(L, n): #main functoin called by the main program file

	Track = quickSort(L, L.head, L.tail, 0)
	return GetMidNode(L, n//2), Track #returns the median and the comparison count
