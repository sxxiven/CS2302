"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 02/22/2019
Discreption: Lab 2:
	The purpose of this program is to sort a given lists with length n using a modified quick sort method. It is 
	modified in the aspedt of soritng only the correct side fo the pivot of which the median is known to resdie.  
	The list comes as a linked lists and returns the median after is is all sorted.  
"""
from BuildLists import GetMidNode

def partion(L, start, end, pivotCount, track): #partion call 
	
	pivotNode = start
	pivotPrev = pivotNode
	transverse = start.next
	
	while transverse != end.next: # loop which does the comparisons
		
		if(start.item >= transverse.item): #items switched in the lists according the the values
			pivotCount +=1
			pivotPrev = pivotNode
			pivotNode = pivotNode.next
			hold = pivotNode.item
			pivotNode.item = transverse.item
			transverse.item = hold

		transverse = transverse.next
		track +=1 #keeps track of the number of comparisons made

	hold = start.item
	start.item = pivotNode.item
	pivotNode.item = hold

	return pivotPrev, pivotCount, track

def quickSort(L, start, end, length, pivotLocation, track): #main recusive sort calls
	
	if start != end and end.next is not start:
		
		previousNode, pivotCount, track = partion(L, start, end, pivotLocation, track) #calls the partion
		
		if pivotCount > length//2: #if mediam resides in the left side, it calls to sort the left
			track = quickSort(L, start, previousNode, length, pivotLocation, track)
		
		elif pivotCount < length//2: #if median resides in teh right sides, it calls to sort the right
			track = quickSort(L, previousNode.next.next, end, length, pivotCount+1, track)
		
		else: #returns the lists
			return track
	return track


def Section4(L, n): #function called from main program file
	
	Track = quickSort(L, L.head, L.tail, n, 0, 0)
	return GetMidNode(L, n//2), Track #returns the comparison count and the median item
