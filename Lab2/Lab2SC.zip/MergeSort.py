"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 02/22/2019
Discreption: Lab 2: 
	The following program sorts a given lists using the merge sort method. After sorting the items in a 
	given linked list, the mediam item is return back to the main files
"""


from BuildLists import Copy
from BuildLists import GetMidNode

def mSort(L, length, track): #merge sort functoin
	
	if length > 1:
		
		mid = length//2
		leftHand = Copy(L, 0, mid)	#creates copies of of the split lists back in Build lists
		rightHand = Copy(L, mid, length)

		track = mSort(leftHand, mid, track)	#recursive calls for futher splitting if neccessairy
		track = mSort(rightHand, length - mid, track)

		leftTemp = leftHand.head
		rightTemp = rightHand.head
		temp = L.head

		while leftTemp is not None and rightTemp is not None:	#loop which does the comparisons

			if leftTemp.item < rightTemp.item:	#updates the value of the passed in lists if it is smaller than the other one
				temp.item = leftTemp.item
				leftTemp = leftTemp.next
				
			else: # updates the passed lists with the other item
				temp.item = rightTemp.item
				rightTemp =rightTemp.next
				
			temp = temp.next
			track += 1	#keeps track of the comparison count
		
		while leftTemp is not None:	#adds left over items to the origional list 
			temp.item = leftTemp.item
			leftTemp = leftTemp.next
			temp = temp.next

		while rightTemp is not None: #adds lef over items to teh origional lists
			temp.item = rightTemp.item
			rightTemp =rightTemp.next
			temp = temp.next
	return track

def Section2(L, n): #function call from the main program file
	
	Track = mSort(L, n, 0)
	return GetMidNode(L, n//2), Track #returns median and comparison count