#********************************************************************************************************************
#Author: Steven J. Robles
#Class: CS 2302 Data Structures III
#Instructor: Olac Fuentes
#TA: Anindita Nath And Maliheh Zargaran
#Last Modified: February 7, 2019
#Discreption: Lab 1: 
#    The purpose of this program is to expierament with recrusive functions by plotting several figures. When each 
#    recursive function is called, the figure should be plotted, but it will be modified. Modification consists of 
#    shrinking and shifting the firgure respectivly to the previous firgures. All of this is done through points 
#    created by the numpy library. The Labs is devided into four sectoin with new drawings within each section. They
#    are seperated into four different files accessed from below. 
#********************************************************************************************************************/

from Squares import Section1
from Squares import RuntimeCheck1
from LeftCircles import Section2
from LeftCircles import RuntimeCheck2
from Tree import Section3
from Tree import RuntimeCheck3
from Circles import Section4
from Circles import RuntimeCheck4

Section1()
Section2()
Section3()
Section4()

n1 = 7
n2 = 51
n3 = 11
n4 = 6

#the section below are the test run time call functions to test the run times of 0 to n
#recursive inputs of each section. They are edited by providing the numbers above. 

#RuntimeCheck1(n1)
#RuntimeCheck2(n2)
#RuntimeCheck3(n3)
#RuntimeCheck4(n4)
