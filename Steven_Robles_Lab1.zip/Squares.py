
#********************************************************************************************************************
#Author: Steven J. Robles
#Class: CS 2302 Data Structures III
#Instructor: Olac Fuentes
#TA: Anindita Nath And Maliheh Zargaran
#Last Modified: February 7, 2019
#Discreption: Lab 1 - Part 1: 
#    The purpose of this program is to expierament with recrusive functions by plotting a series of squares. Each 
#    is reduced by half repsectivley form the previous square and is shifted to all four corners of the previous 
#    square.  
#********************************************************************************************************************/
import matplotlib.pyplot as plt
import numpy as np
import timeit

#recurse fucntion of which shrinks, shifts, and plots the squares
def draw_squares(ax,n,p,w, length):
    if n>0:
        
        #the followin shifts the squares 75% and/or 25% of the previous length of the square
        bigShift = length*.75
        smallShift = length*.25 

        points = [0, 1 , 2, 3, 4]

        #top left square
        q = p*w
        q[points, 0] -= smallShift
        q[points, 1] += bigShift
        ax.plot(p[:,0],p[:,1],color='k')
        draw_squares(ax,n-1,q,w, length)
        
        #top right squares
        q = p*w
        q[points] += bigShift
        ax.plot(p[:,0],p[:,1],color='k')
        draw_squares(ax,n-1,q,w, length)
        
        #Bottom Left Square
        q = p*w
        q[points] -= smallShift
        ax.plot(p[:,0],p[:,1],color='k')
        draw_squares(ax,n-1,q,w, length)
        
        #Bottom Right Square
        q = p*w
        q[points, 0] += bigShift
        q[points, 1] -= smallShift
        ax.plot(p[:,0],p[:,1],color='k')
        draw_squares(ax,n-1,q,w, length)

#This definition is called from the main program of which initiates the recursive call. It also sets up and 
#show the plots produced in a pair of three. 
def Section1():
    plt.close("all") 
    orig_size = 524288
    p = np.array([[0,0],[0,orig_size],[orig_size,orig_size],[orig_size,0],[0,0]])
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, sharex = True,sharey = True)
    ax1.axis('on')
    ax1.set_aspect(1.0)
    ax1.yaxis.set_major_locator(plt.NullLocator())
    ax1.xaxis.set_major_locator(plt.NullLocator())
    ax1.set_title('Two Recursios')
    ax2.set_title('Three Recursions')
    ax3.set_title('Four Recursions')
    draw_squares(ax1,2,p, .50, orig_size)
    draw_squares(ax2,3,p, .50, orig_size)
    draw_squares(ax3,4,p, .50, orig_size)
    plt.show()
    fig.savefig('Squares.png')

#The following definition is called to check the runtime of the program when there are 0 recursion called up to 7
# and plots the results
def RuntimeCheck1(n):

    #sets the size of the array of which the run times are going to be stored
    times = [0] * n 

    orig_size = 2147483648
    p = np.array([[0,0],[0,orig_size],[orig_size,orig_size],[orig_size,0],[0,0]])
    fig, ax = plt.subplots()


    #this loop is Not recursice. It calls the recursive function from 0 to n times and stores the time onto the previous array
    for i in range(len(times)):        
        start = timeit.default_timer() # starts timer
        
        draw_squares(ax,i,p, .50, orig_size)
        
        stop = timeit.default_timer() # ends timer
        times[i] = stop - start #stores the lapsed time 

    #proceeds to plot the results
    plt.close("all") 
    plt.title('Run Time of Section 1')
    plt.xlabel('Number of Recursions')
    plt.ylabel('Time (Seconds)')
    x = np.arange(0,n,1)
    plt.plot(x, times, 'k', x, times, 'ro') 
    plt.savefig('1_Runtime')
    plt.show()






