#********************************************************************************************************************
#Author: Steven J. Robles
#Class: CS 2302 Data Structures III
#Instructor: Olac Fuentes
#TA: Anindita Nath And Maliheh Zargaran
#Last Modified: February 7, 2019
#Discreption: Lab 1 - Part 2: 
#    The purpose of this program is to expierament with recrusive functions by plotting a series of circles which are
#    reduced by specific percent and shift so thhe left most point of the new circle is aligned with the previous left 
#    most point of the cirlce. The percantage of the radius reduced and the amount of shifting depends on the number of
#    recersions which is already provide in the code.  
#********************************************************************************************************************/
import matplotlib.pyplot as plt
import numpy as np
import math 
import timeit

#The following creats the cirlce with the given center point and radius
def circle(center,rad):
    n = int(4*rad*math.pi)
    t = np.linspace(0,6.3,n)
    x = center[0] + rad*np.sin(t)
    y = center[1] + rad*np.cos(t)
    return x,y

#The following function is the recrusive function of which plots the cricle, and reduces and shifts the next one. 
def draw_circles(ax,n,center,radius,w):
    if n>0:

        center[0] = radius * .9999  # Shifts the next circle .0001% to the right of the left side
                                    # so you can tell its a new circle
        x,y = circle(center,radius)
        ax.plot(x,y,color='k')
        draw_circles(ax,n-1,center,(radius*w),w)

#This definition is called from the main program of which initiates the recursive call. It also sets up and 
#show the plots produced in a pair of three
def Section2():
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, sharex = True,sharey = True)
    ax1.axis('on')
    ax1.set_aspect(1.0)
    ax1.yaxis.set_major_locator(plt.NullLocator())
    ax1.xaxis.set_major_locator(plt.NullLocator())
    ax1.set_title('Eight Recursios')
    ax2.set_title('Thirty Recursions')
    ax3.set_title('Fifty Recursions')
    draw_circles(ax1, 8, [500, 0], 500, .50)
    draw_circles(ax2, 30, [500, 0], 500, .75)
    draw_circles(ax3, 50, [500, 0], 500, .90)
    plt.show()
    fig.savefig('LeftCircles.png')

#The following definition is called to check the runtime of the program when there are 0 recursion called up to 50
# and plots the results
def RuntimeCheck2(n):

    #sets the size of the array of which the run times are going to be stored
    times = [0] * n 
    fig, ax = plt.subplots()

    #this loop is Not recursice. It calls the recursive function from 0 to n times and stores the time onto the previous array
    for i in range(len(times)):

        
        start = timeit.default_timer() # starts timer
        
        draw_circles(ax, n, [500, 0], 500, .90)

        stop = timeit.default_timer() # ends timer

        times[i] = stop - start #stores the lapsed time 

    #proceeds to plot the results
    plt.close("all") 
    plt.title('Run Time of Part 2')
    plt.xlabel('Number of Recursions')
    plt.ylabel('Time (Seconds)')
    x = np.arange(0,n,1)
    plt.plot(x, times, 'k', x, times, 'ro') 
    plt.savefig('2_Runtime')
    plt.show()