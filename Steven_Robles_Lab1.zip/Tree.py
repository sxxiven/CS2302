#********************************************************************************************************************
#Author: Steven J. Robles
#Class: CS 2302 Data Structures III
#Instructor: Olac Fuentes
#TA: Anindita Nath And Maliheh Zargaran
#Last Modified: February 7, 2019
#Discreption: Lab 1 - Section 3: 
#    The purpose of this program is to expierament with recrusive functions by plotting a series of trees which
# 	 are applieds a new level to the tree each recursive call.   
import numpy as np
import matplotlib.pyplot as plt
import timeit

#the following is the recursive function which creates a new level by adding two children to the bottom leafs
def draw_trees(ax,n,p,w, h, wt):
    if n>0:
        
        #the followin adds two children to the left leaf
        endPoints = [0,2]
        q =  p * 1.0001
        q[1] = p[0]			#sets the midle point of the new leafs to the end of the previous one. 
        #The folloiwng to lines makes sure the length of the new leafs in the x direction is half from the previous one
        q[0,0] -= w*wt 
        q[2,0] -= (1+w)*wt
        q[endPoints,1] -= h
        wt1 = q[1,0]- q[0,0]
        ax.plot(p[:,0],p[:,1],color='k')
        draw_trees(ax,n-1,q,w, h, wt1)

        #the following adds children to the right leaf
        q =  p * 1.0001
        q[1] = p[2]			#sets the midle point of the new leafs to the end of the previous one.
        #The folloiwng to lines makes sure the length of the new leafs in the x direction is half from the previous one 
        q[0,0] += (1+w)*wt
        q[2,0] += w*wt
        q[endPoints,1] -= h
        ax.plot(p[:,0],p[:,1],color='k')
        draw_trees(ax,n-1,q,w, h, wt1)

#This definition is called from the main program of which initiates the recursive call. It also sets up and 
#show the plots produced in a pair of three. 
def Section3():        
	fig, (ax1, ax2, ax3) = plt.subplots(1, 3, sharex = True,sharey = True)
	ax1.axis('on')
	ax1.set_aspect(1.0)
	ax1.yaxis.set_major_locator(plt.NullLocator())
	ax1.xaxis.set_major_locator(plt.NullLocator())
	ax1.set_title('Three Recursios')
	ax2.set_title('Four Recursions')
	ax3.set_title('Seven Recursions')
	height = 800
	width = 2000
	p = np.array([[100,100],[2100,900],[4100,100]])
	draw_trees(ax1,3,p,.5, height, width)
	draw_trees(ax2,4,p,.5, height, width)
	draw_trees(ax3,7,p,.5, height, width)
	plt.show()
	fig.savefig('Trees.png')

#The following definition is called to check the runtime of the program when there are 0 recursion called up to 50
# and plots the results
def RuntimeCheck3(n):

    #sets the size of the array of which the run times are going to be stored
    times = [0] * n 
    fig, ax = plt.subplots()
    height = 800
    width = 2000
    p = np.array([[100,100],[2100,900],[4100,100]])

    #this loop is Not recursice. It calls the recursive function from 0 to n times and stores the time onto the previous array
    for i in range(len(times)):
        
        start = timeit.default_timer() # starts timer
        
        draw_trees(ax,i,p,.5, height, width)

        stop = timeit.default_timer() # ends timer

        times[i] = stop - start #stores the lapsed time 

    #proceeds to plot the results
    plt.close("all") 
    plt.title('Run Time of Part 3')
    plt.xlabel('Number of Recursions')
    plt.ylabel('Time (Seconds)')
    x = np.arange(0,n,1)
    plt.plot(x, times, 'k', x, times, 'ro') 
    plt.savefig('3_Runtime')
    plt.show()
