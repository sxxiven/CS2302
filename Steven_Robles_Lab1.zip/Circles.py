#********************************************************************************************************************
#Author: Steven J. Robles
#Class: CS 2302 Data Structures III
#Instructor: Olac Fuentes
#TA: Anindita Nath And Maliheh Zargaran
#Last Modified: February 7, 2019
#Discreption: Lab 1 - Section 4: 
#    The purpose of this program is to expierament with recrusive functions by plotting a series of circles which are
#    by 66% and placed in the middle, top, right, bottom and left of the previous cirlce. This will cause a patter of 
#    cirlces within circles which demonstrates the effectivness of recersion algrorythims
#********************************************************************************************************************/
import matplotlib.pyplot as plt
import numpy as np
import math 
import timeit

#The following constructs the circle given the center point and its radius
def circle(center,rad):
    n = int(10*rad*math.pi)
    t = np.linspace(0,6.3,n)
    x = center[0]+rad*np.sin(t)
    y = center[1]+rad*np.cos(t)
    return x,y

#The recursive function reduces and shifts 4 circles accroding to their destinations respective to the previous cricle
def draw_circles(ax,n,center,radius,w):
    if n>0:

        #plots the origional sized cricle "Parent"
        x,y = circle(center,radius)
        ax.plot(x,y,color='k')

        #plots the reduced circle in the middle
        x,y = circle(center,radius*w)
        ax.plot(x,y,color='k')
        draw_circles(ax,n-1,center,(radius*w),w)    
        #plots the reduced circle in the to the right
        center2 = center
        center2[0] -= radius*.66    #shifts the center point to the right
        x,y = circle(center2,radius*w)
        ax.plot(x,y,color='k')
        draw_circles(ax,n-1,center,(radius*w),w)
        center2[0] += radius*.66   #shifts the center point back to its oriigional locatoins -- same with all of the rest

        #plots the reduced circle in the to the left
        center2 = center
        center2[0] += radius*.66
        x,y = circle(center2,radius*w)
        ax.plot(x,y,color='k')
        draw_circles(ax,n-1,center,(radius*w),w)
        center2[0] -= radius*.66

    #plots the reduced circle in the to the top
        center2 = center
        center2[1] -= radius*.66
        x,y = circle(center2,radius*w)
        ax.plot(x,y,color='k')
        draw_circles(ax,n-1,center,(radius*w),w)
        center2[1] += radius*.66

    #plots the reduced circle in the to the bottom
        center2 = center
        center2[1] += radius*.66
        x,y = circle(center2,radius*w)
        ax.plot(x,y,color='k')
        draw_circles(ax,n-1,center,(radius*w),w)
        center2[1] -= radius*.66

#This definition is called from the main program of which initiates the recursive call. It also sets up and 
#show the plots produced in a pair of three
def Section4():     
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, sharex = True,sharey = True)
    ax1.axis('on')
    ax1.set_aspect(1.0)
    ax1.yaxis.set_major_locator(plt.NullLocator())
    ax1.xaxis.set_major_locator(plt.NullLocator())
    ax1.set_title('One Recursios')
    ax2.set_title('Two Recursions')
    ax3.set_title('Three Recursions')
    draw_circles(ax1, 1, [0, 0], 20,.33 )
    draw_circles(ax2, 2, [0, 0], 20,.33 )
    draw_circles(ax3, 3, [0, 0], 20,.33 )
    plt.show()
    fig.savefig('Circles.png')

#The following definition is called to check the runtime of the program when there are 0 recursion called up to 50
# and plots the results
def RuntimeCheck4(n):

    #sets the size of the array of which the run times are going to be stored
    times = [0] * n 
    fig, ax = plt.subplots()

    #this loop is Not recursice. It calls the recursive function from 0 to n times and stores the time onto the previous array
    for i in range(len(times)):
        
        start = timeit.default_timer() # starts timer
        
        draw_circles(ax, i, [0, 0], 20,.33 )

        stop = timeit.default_timer() # ends timer

        times[i] = stop - start #stores the lapsed time 

    #proceeds to plot the results
    plt.close("all") 
    plt.title('Run Time of Part 4')
    plt.xlabel('Number of Recursions')
    plt.ylabel('Time (Seconds)')
    x = np.arange(0,n,1)
    plt.plot(x, times, 'k', x, times, 'ro') 
    plt.savefig('4_Runtime')
    plt.show()