"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 05/09/2019
Discreption: Lab 8: 
        This program is desinged to to check the validation of any two given grigonomic fucntions through randamization
        desing. The trigonomic funciton is listed and each combination is compared and displayed 
"""
import random
import numpy as np
from mpmath import *
import math
import mpmath 

def equal(f1, f2,tries=1000,tolerance=0.0001):
    #this if statment repeats for 1000 times for high probability of success
    for i in range(tries):
        t = random.uniform(-math.pi, math.pi)
        y1 = eval(f1)
        y2 = eval(f2)
        if np.abs(y1-y2)>tolerance:
            return False #there is too much differene thus they are not the same
    return True

def TrigCombo():
    trigFucntions = ['sin(t)', 'cos(t)','tan(t)', 'sec(t)', 'sin(t)*-1', 'cos(t)*-1', 'tan(t)*-1', 'sin(t*-1)', 'cos(t*-1)', 'tan(t*-1)', 'sin(t)/cos(t)', '2*sin(t/2)*cos(t/2)', 'sin(t)*sin(t)', '((cos(t)*cos(t)) *-1) +1', '((cos(2*t)*-1)+1)/2', '1/cos(t)']
    displayTrigCombo = ['sin(t)', 'cos(t)', 'tan(t)', 'sec(t)', '−sin(t)', '−cos(t)', '−tan(t)', 'sin(−t)', 'cos(−t)', 'tan(−t)', 'sin(t)/cos(t)', '2sin(t/2)cos(t/2)', 'sin^2(t)', '1−cos^2(t)', '1−cos(2t)/2', '1/cos(t)']

    for i in range(len(trigFucntions)): #nested foor loops does a permutatoin transverse
        for j in range(i,len(trigFucntions)):
            print(displayTrigCombo[i], ' And ', displayTrigCombo[j], end=': ') 
            print(equal(trigFucntions[i], trigFucntions[j]))

