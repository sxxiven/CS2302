"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 05/09/2019
Discreption: Lab 8: 
		This program is desinged to take set of numbers and partition it into two sets where the sum of both sets 
		equals to the sum of the origional set. Also, the numbers within both new sets are not the same. If there
		is not possible partiions for the requirements, it would tell so.  
"""

#the main recursice 'backtracking' function
def partition(S,last, part, part2, currSum, goal, construct2=False):
	if construct2 and last >= 0: #this if statment exits to fill the rest of the items when set 1 is solved
		part2.append(S[last]) 
		return partition(S,last-1, part, part2, 0, goal, True)

	if currSum == goal: #goal of the sum is met
		partition(S,last, part, part2, 0, goal, True)
		return True

	if goal < currSum  or last < 0: #the current combination is not possible
		return False

	res = partition(S,last-1,part, part2, currSum+S[last], goal) #Takes S[last]
	
	if res : #set1 is solved and appended
		part.append(S[last])
		return True
	
	else:
		part2.append(S[last]) #since it was not part of the path, it is passed to set2
		return partition(S,last-1, part, part2, currSum, goal) # kips S[last]


#function called from the main program
def findPartition(numSet2):
	print('Chosen Set: ', numSet2)
	total = 0
	for i in range(len(numSet2)): #gets the total sum first 
		total += numSet2[i]
	if total % 2 == 1: #if the sum is odd, then the subests dont exits
		print("There is no partitions")

	else: 
		set1, set2 = [], []
		partition(numSet2, len(numSet2)-1, set1, set2, 0,total//2)
		if len(set1)>0: #prints each subset is solvable
			set1.sort()
			set2.sort()
			print('Partitions of subset 1 : ', set1)
			print('Partitions of subset 2 : ', set2)
		else: 
			print("There is no partitions")
