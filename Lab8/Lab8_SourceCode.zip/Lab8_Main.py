"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 05/09/2019
Discreption: Lab 8: 
		This program is desinged to act as the main file of this lab. It produces the main menu and recieves
		user input to call funcitons. It also records the time it takes to partition different sets. 
"""

from Randomized import TrigCombo
from Backtrack import findPartition
import matplotlib.pyplot as plt
import numpy as np
import timeit


loop = True #commences the loop

#the is the while loop which pompts the user. 
while loop:
	print("1. Triginomic Functions\n2. Sum Partitions\n3. Time Trial")
	number = input("4. Exit\n")
	print("*************************")
	#trys converting the input into an int. if it fails, the pormpt runs again
	try: 
		choice = int(number)
	except: 
		choice = -1

	#The fist if statement does the trigonmaic functions
	if choice == 1:
		TrigCombo()

	if choice == 2: 	#The second if statement does the does the partion functions
		loop2 = True
		S = []
		while loop2:
			print("Enter a value to insert into the origiona subet :")
			choice = input("Enter 'done' to indicate when finished : \n")

			if choice != 'done': 
				#the following converts the input into ints if it's possible
				try : 
					choice = int(choice)
					S.append(choice)
				except: 
					print("Try Again")
			else : 
				loop2 = False
		print("*************************")
		S.sort()
		findPartition(S)


	#Choice number two times the preformance of the functions with a determined 
	#set of sisze mazes. 
	elif choice == 3: 
		numSet = [[2,5,8,9,12,21,33], [2, 4, 5, 9, 12], [1,2,3,4,6], [2, 4, 6, 70], [12,13,14,21,25,32], [2,4,6,80]]
		times = []
		for i in range(len(numSet)):
			start = timeit.default_timer() # starts timer
			findPartition(numSet[i])
			stop = timeit.default_timer() # ends timers
			times.append(stop-start)

		fig, ax = plt.subplots()
		#proceeds to plot the time results
		plt.xlabel('Size of Maze (M x N')
		plt.ylabel('Time (Seconds)')
		x = np.arange(0,30,5)
		plt.plot(x, times, 'k', label= 'BFS')
		plt.legend()
		plt.savefig('RunTimes')
		plt.show()
	#program exits
	elif choice == 4: 
		print("Good Bye!")
		loop = False
	else: 
		print("Try Again")
	print("*************************")
