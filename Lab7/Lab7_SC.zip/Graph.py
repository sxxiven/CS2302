"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 04/29/2019
Discreption: Lab 7: 
        The purpose of this program is to build construct a adjecancy lists for a graph based on the
        maze matrix. This graph will be utilized to solve the mazes in three different approcahes: 
        BFS, DFS - Stacked, and DFS - Recursive 
     
""" 
import math 

#bulds the graph giaven the walls lists
def buildGraph(walls, rows, columns): 
	G = [[] for i in range(rows*columns)]
	v = 0
	#checks if there is a wall between to cells before making an edge
	while v <rows*columns: 
		if (v + 1) %columns != 0 and [v, v+1] not in walls and [v+1, v] not in walls:
			G[v].append(v+1)
		if v %columns != 0 and [v, v-1] not in walls and [v-1, v] not in walls:
			G[v].append(v-1)
		if v - columns >= 0 and [v, v-columns] not in walls and [v-columns, v] not in walls:
			G[v].append(v-columns)
		if v +columns < rows*columns and [v, v+columns] not in walls and [v+columns, v] not in walls:
			G[v].append(v+columns)
		v+=1
	return G

#BFS method approach
def BFS(G, v):
	Q = []
	visited = [False]*(len(G))
	prev = [-1] * (len(G))
	Q.append(v)
	visited[v] = True
	while len(Q) > 0 :
		u = Q.pop(0)
		for t in G[u]:
			if visited[t]== False:
				visited[t] = True
				prev[t] = u
				Q.append(t)
	return prev

#DFS stack approach
def DFS_Stack(G, v): 
	Q = []
	visited = [False]*(len(G))
	prev = [-1] * (len(G))
	Q.append(v)
	visited[v] = True
	while len(Q) > 0 :
		u = Q.pop()
		for t in G[u]:
			if visited[t]== False:
				visited[t] = True
				prev[t] = u
				Q.append(t)
	return prev

#DFS recursion approach
def DFS_Rec(G, source, visited, prev, final): 
	visited[source] = True
	if source == final: 
		return prev, True
	for t in G[source]:
		if visited[t] == False: 
			prev, add = DFS_Rec(G, t, visited, prev, final)
			if add: 
				prev.append(t)
				return prev, True
	return prev, False   

#builds the graph in an adjecancy list for the other methods
def mazeGraph(walls, rows, columns): 
	G = buildGraph(walls, rows, columns)
	return G



