"""
Author: Steven J. Robles
Class: CS 2302 Data Structures III
Instructor: Olac Fuentes
TA: Anindita Nath And Maliheh Zargaran
Last Modified: 04/29/2019
Discreption: Lab 7: 
        This program is desinged to act as the main file of this project. It produces the main menu and recieves
        user input to call funcitons. It also records the time it takes for each maze to be built. 
    

"""

from BuildMaze import initiateMazeC
import matplotlib.pyplot as plt
import numpy as np
import timeit


loop = True #commences the loop

#the is the while loop which pompts the user. 
while loop:
	print("1. Build and Graph Maze\n2. Time Trail")
	number = input("3. Exit\n")
	print("*************************")
	#trys converting the input into an int. if it fails, the pormpt runs again
	try: 
		choice = int(number)
	except: 
		choice = -1

	#The fist if statement bulds the maze by asking of its dimensions first
	if choice == 1:
		cont = True
		while cont:
			rows = input("Enter value for rows : \n")
			cols = input("Enter value for columns : \n")
			remove = input("Enter number of rows to be removed : \n")
			#the following converts the input into ints if it's possible
			try : 
				rows = int (rows)
				cols = int(cols)
				remove = int(remove)
				if remove < 0: 
					print("Try Again")
				else : 
					cont = False

			except: 
				print("Try Again")
		print()
		if remove < rows*cols -1: 
			print('A path from source to destination is not guaranteed to exist')
		elif remove == rows*cols -1: 
			print('The is a unique path from source to destination')
			initiateMazeC(rows, cols,start, end, True)
		else: 
			print('There is at least one path from source to destination')

	#Choice number two times the preformance of the functions with a determined 
	#set of sisze mazes. 
	elif choice == 2: 
		dimensions = [[5,5],[10,10],[15,15],[20,20],[25,25],[30,30]]
		times = [[],[],[]]
		for i in range(len(dimensions)):
			#times the BFS
			start = timeit.default_timer() # starts timer
			initiateMazeC(dimensions[i][0], dimensions[i][1], 0, (dimensions[i][0]*dimensions[i][1])-1, False, 1, True)
			stop = timeit.default_timer() # ends timers
			times[0].append(stop-start)
			#times the DFS _ Stack
			start = timeit.default_timer() # starts timer
			initiateMazeC(dimensions[i][0], dimensions[i][1], 0, (dimensions[i][0]*dimensions[i][1])-1, False, 2, True)
			stop = timeit.default_timer() # ends timers
			times[1].append(stop-start)
			#times hte DFs _ Recursion
			start = timeit.default_timer() # starts timer
			initiateMazeC(dimensions[i][0], dimensions[i][1], 0, (dimensions[i][0]*dimensions[i][1])-1, False, 3, True)
			stop = timeit.default_timer() # ends timers
			times[2].append(stop-start)

		fig, ax = plt.subplots()
	    #proceeds to plot the time results
		plt.xlabel('Size of Maze (M x N')
		plt.ylabel('Time (Seconds)')
		x = np.arange(0,30,5)
		plt.plot(x, times[0], 'k', label= 'BFS')
		plt.plot(x, times[1], 'r', label='DFS-Stack') 
		plt.plot(x, times[2], 'b', label='DFS-Rec')
		plt.legend()
		plt.savefig('RunTimes')
		plt.show()
	#program exits
	elif choice == 3: 
		print("Good Bye!")
		loop = False
	else: 
		print("Try Again")
	print("*************************")
